<?php

$_['form_title'] = 'Fill out the form';

$_['entry_unit_title'] = 'Name';
$_['help_unit_title'] = 'Enter the full name of the measurement units';
$_['placeholder_unit_title'] = 'Enter the full name of the measurement units';

$_['entry_unit'] = 'The designation';
$_['help_unit'] = 'Enter the abbreviated name of the units';
$_['placeholder_unit'] = 'Enter the abbreviature';
$_['error_required'] = 'This field should not be empty';